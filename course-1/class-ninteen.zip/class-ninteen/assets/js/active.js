(function($){
    "use strict";
    
    
//     document ready 
    jQuery(document).ready(function($){
        

        

});

    
 

    
    
    
    
    
    
    
    
    
})(jQuery);